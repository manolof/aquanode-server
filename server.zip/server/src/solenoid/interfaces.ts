export enum SolenoidStatus {
	off = 'off',
	on = 'on',
}

export interface SolenoidPins {
	solenoid: number;
}
