export const environment = {
	production: true,
	endpoint: 'http://localhost:3000/api'
};
