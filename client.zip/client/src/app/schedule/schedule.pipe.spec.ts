import { SchedulePipe } from './schedule.pipe';

describe('SchedulePipe', () => {
  it('create an instance', () => {
    const pipe = new SchedulePipe();
    expect(pipe).toBeTruthy();
  });
});
